import Scene from "./components/scene";

function App() {
  return (
    <div>
      <Scene />
    </div>
  );
}

export default App;
